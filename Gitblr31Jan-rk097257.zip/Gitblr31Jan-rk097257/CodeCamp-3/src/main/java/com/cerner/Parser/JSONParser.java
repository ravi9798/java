package com.cerner.Parser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;
public class JSONParser {
	static String UrlString = "";
	public static String getParser(String urlString) throws IOException {
		try {
			UrlString = urlString;
			URL urlObj = new URL(UrlString);
			HttpURLConnection conectionString = (HttpURLConnection) urlObj.openConnection();
			
			InputStreamReader objInputStreamReader = new InputStreamReader(conectionString.getInputStream());
			BufferedReader inputBufferReader = new BufferedReader(objInputStreamReader);
			String inputStream;
			StringBuffer responseBuffer = new StringBuffer();
			while((inputStream = inputBufferReader.readLine()) != null)
			{
				responseBuffer.append(inputStream);
			}
			
			return responseBuffer.toString();
		} catch (Exception ex) {
			return ex.toString();
		}
		
	}

}