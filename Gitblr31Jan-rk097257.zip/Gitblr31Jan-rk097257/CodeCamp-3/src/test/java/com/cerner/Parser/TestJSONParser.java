package com.cerner.Parser;

import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;


public class TestJSONParser {

	JSONObject objJSON ;
	String urlString = "https://en.wikipedia.org/w/api.php?format=json&action=query&titles=SMALL&prop=revisions&rvprop=content";
	
	
	@Test
	public void test() {
			try {
				
				String responseResult = JSONParser.getParser(urlString);
				objJSON = new JSONObject(responseResult);
				
				JSONObject myResponse = new JSONObject(responseResult);	
				JSONObject queryObj = myResponse.getJSONObject("query");
				JSONObject pagesObj = queryObj.getJSONObject("pages");
				JSONObject pageidObj = pagesObj.getJSONObject("1808130");
				JSONArray arrayObj = pageidObj.getJSONArray("revisions");
				
				
				System.out.println("Page id : "+pageidObj.getInt("pageid"));
				
				
				
				String seeAlsoResult = arrayObj.getJSONObject(0).getString("*") ;
				System.out.println("See Also : "+ seeAlsoResult);
						
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
