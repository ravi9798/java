package com.cernertraining.codecamp2;

import java.util.List;

public class Customer {
	String CustName;
	public Customer(String CustName) {
		this.CustName = CustName;
	}
	
	List<Items> ItemList;
	
	public int calculateBill()
	{
		int sum = 0;
		for(Items tlist:ItemList)
		{
			sum = sum + tlist.getItemPrice(tlist.getItemName());
		}
		return sum;
	}
	public String getCustName() {
		return CustName;
	}
 
	public void setCustName(String CustName) {
		this.CustName = CustName;
	}
 

 
	public void setListOfItems(List<Items> itemslist) {
		this.ItemList = itemslist;
	}
}
