package com.cernertraining.codecamp2;

public interface Items {
	String getItemName();
	int getItemPrice(String ItemName);
}
