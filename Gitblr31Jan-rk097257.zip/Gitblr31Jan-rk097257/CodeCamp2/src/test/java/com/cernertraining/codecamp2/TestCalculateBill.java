/**
 * 
 */
package com.cernertraining.codecamp2;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

/**
 * @author RK097257
 *
 */
public class TestCalculateBill {

	Customer custObj;
	@Before
	public void setUp()  {
		
		//Creation of the object
		custObj = new Customer("Ravi");
		
		List<Items> ItemList = new ArrayList<Items>();
		//declaring objects for items
		Items item1;
	    Items item2;
	    Items item3;
	    Items item4; 
	    
	    //mocking item objects
	    
	    item1 = Mockito.mock(Items.class);
	    item2 = Mockito.mock(Items.class);
	    item3 = Mockito.mock(Items.class);
	    item4 = Mockito.mock(Items.class);
	    
	    //adding mock objects of items in List
		ItemList.add(item1);
		ItemList.add(item2);
		ItemList.add(item3);
		ItemList.add(item4);
		
		//initializing List
		custObj.setListOfItems(ItemList);
		
		
		when(item1.getItemName()).thenReturn("IPhone");
		when(item2.getItemName()).thenReturn("AirPods");
		when(item3.getItemName()).thenReturn("MacBook");
		when(item4.getItemName()).thenReturn("IPad");
		 
		when(item1.getItemPrice("IPhone")).thenReturn(4000);
		when(item2.getItemPrice("AirPods")).thenReturn(2000);
		when(item3.getItemPrice("MacBook")).thenReturn(3000);
		when(item4.getItemPrice("IPad")).thenReturn(1000);
		
	}

	
	

	@Test
	public void test() {
		int sum = custObj.calculateBill();
		Assert.assertEquals(10000,sum);
	}

}
