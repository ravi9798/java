package com.cernertraining.codecamp1;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestCombinationOfThree {
	CombinationOfThree obj = new CombinationOfThree();
	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	public void CheckArrayLength1() {
		Throwable ex = assertThrows(IllegalArgumentException.class,() ->{
			int[] arr = new int[] {1};
			assertEquals("Array Length cannot be less than 2.",obj.getCombination(arr, 5));
		});
	}
	@Test
	public void CheckItemCombination() {
		int[] arr = new int[] {1,2,3,4,5,6,7,8,9,10};
		assertEquals(1,obj.getCombination(arr, 10));
	}
	@Test
	public void CheckItemCombinationNull() {
		int[] arr = new int[] {1,2,3,4,5,6,7,8,9,10};
		assertEquals(-1,obj.getCombination(arr, 100));
	}

}
