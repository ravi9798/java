package com.cernertraining.codecamp1;



import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestCombinationOfTwo {
	CombinationOfTwo obj = new CombinationOfTwo();
	@Before
	public void setUp() {
		CombinationOfTwo obj = new CombinationOfTwo();
	}

	@After
	public void tearDown() {
	}

	@Test
	public void CheckArrayLength1() {
		Throwable ex = assertThrows(IllegalArgumentException.class,() ->{
			int[] arr = new int[] {1};
			assertEquals("Array Length cannot be less than 2.",obj.getCombination(arr, 5));
		});
	}
	@Test
	public void CheckItemCombination() {
		int[] arr = new int[] {1,2,3,4,5,6,7,8,9,10};
		assertEquals(1,obj.getCombination(arr, 10));
	}
	@Test
	public void CheckItemCombinationNull() {
		int[] arr = new int[] {1,2,3,4,5,6,7,8,9,10};
		assertEquals(-1,obj.getCombination(arr, 100));
	}
	
	


}
