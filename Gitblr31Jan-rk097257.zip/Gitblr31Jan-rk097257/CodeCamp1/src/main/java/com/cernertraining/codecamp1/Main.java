package com.cernertraining.codecamp1;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
		//object of the Combination class
		CombinationOfTwo obj = new CombinationOfTwo();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number of Items: ");
		int len = sc.nextInt(); // taking input for array length
		System.out.println("Enter Items: ");
		int[] arr = new int[len];  //declaring array
		for(int i=0;i<len;i++) {
			//taking input into the array
			arr[i] = sc.nextInt();
			
		}
		//getting result 
		int result = obj.getCombination(arr, len);
		System.out.println(result);
		
		//printing all the pairs
		obj.printCombinations(arr,len);
		sc.close();
	}
}
