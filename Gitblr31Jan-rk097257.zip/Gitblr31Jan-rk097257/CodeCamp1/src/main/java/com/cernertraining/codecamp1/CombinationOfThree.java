package com.cernertraining.codecamp1;

public class CombinationOfThree {
	
	//Method that takes an array as input and a desired value
	public int getCombination(int[] arr, int m) {
		
		//check for length of the array
		if(arr.length < 2) {
			
			//throw exception when array length is less than 2
			throw new IllegalArgumentException("Array Length cannot be less than 2.");
		}
		else {
			//declaring a flag variable to store the result
			int flag = -1;
			
			//loop statement to get all combination of pairs
			for(int i=0;i<arr.length-2;i++) {
				for(int j=i+1;j<arr.length-1;j++) {
					for(int k=j+1;k<arr.length;k++) {
						//check each combination for its sum equal to given number
						if(arr[i]+arr[j]+arr[k] == m) {
							flag = 1;
							//breaking the loop as pair found
							break;
						}
					}
					if(flag == 1)
						break;
					
				}
				if(flag == 1)
					break;
			}
			//returning the result
			return flag;
		}
	}
	//method to display all pairs
	public void printCombinations(int[] arr,int m) {
		//loop for iterating each items
		for(int i=0;i<arr.length-1;i++) {
			for(int j=i;j<arr.length;j++) {
				for(int k=j+1;k<arr.length;k++) {
					//check for the sum equals to the value
					if(arr[i]+arr[j]+arr[k] == m) {
						//print the combination pair
						System.out.println(arr[i]+", "+arr[j]+" and "+arr[k]);
					}
				}
				
			}
		}
	}
}
